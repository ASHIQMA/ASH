export class CustomerDetails {
  id: number;
  name: string;
  email : string;
  phone : string;
  city : string;
  state : string;
  country : string;
  organization : string;
  jobProfile : string;
  additionalInfo : string;
}
